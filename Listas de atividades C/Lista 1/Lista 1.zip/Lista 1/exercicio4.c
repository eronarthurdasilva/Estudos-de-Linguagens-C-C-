#include <stdio.h>
#include <stdlib.h>

int main()
{
//Armazenando os valores inteiros a serem usados
   int n;
   printf("Digite um numero inteiro \n",n);// pedirei ao usuario para digitar um numero inteiro
   scanf("%d",&n);// dados de entrada
   printf("\ esse e o seu numero sucessor %d",++n);//Ira exibir o numero sucesssor do escolhido pelo usuario


}
