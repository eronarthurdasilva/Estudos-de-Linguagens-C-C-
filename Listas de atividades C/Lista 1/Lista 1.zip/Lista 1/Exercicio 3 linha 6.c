#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Ira apresentar as vari�veis para a,b,c e d
    int a,b,c,d;
    printf("%d %d %d %d", a, b, c, d);// ira printar os valores das vari�veis a, b, c, d
}
